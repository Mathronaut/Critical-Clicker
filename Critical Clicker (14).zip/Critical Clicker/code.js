//vars
var id;
var user = getUserId();
var clicks = 0;
var pointsperclick = 1;
var CPS = 0;
var Ach = {"oneclick":false, "100":false, "Joe":false, "Cps":false, "ascend":false, "Add":false};
//Users
if (getUserId() == "weTtnsWPmMYoT3lUNTloe5jZ8YI") {
  createRecord("Sawyer", {name:'Saywer'}, function() {
    
  });
}
if (getUserId() == "spbyKS4IXwoOw6fGZg68moRUGOI") {
  createRecord("FINN", {Time:Date(), Name:'Finn'}, function() {
    
  });
}
if (getUserId() == "6Cj5zbhhmkXGpEvTH9JcYCtfEyk") {
  createRecord("PALMER", {Time:Date(), name:'Palmer'}, function() {
    
  });
}
if (getUserId() == "cjSxdurpVE66vRq3MC+TG8IlPUs") {
  createRecord("Louis", {Time:(Date()), name:'Louis'}, function() {
    
  });
}
//Event
onEvent("Play", "click", function( ) {
  setScreen("Rules");
});
onEvent("understand", "click", function( ) {
  setScreen("Clicker");
});
timedLoop(1000, function() {
  clicks = clicks + CPS;
  setText("labelCounter", clicks);
  advancment();
  Saves();
});
onEvent("buttonclick", "mousedown", function( ) {
  clicks = clicks + pointsperclick;
  setText("labelCounter", clicks);
  if (clicks == randomNumber(1, 1000)) {
  setScreen("Add");
  playSound("assets/GG.mp3", false);
}
  setTimeout(function() {
    setProperty("Skip", "hidden", false);
  }, randomNumber(1000, 10000));
});
setProperty("Skip", "hidden", true);
onEvent("buttonbuyautocler1", "click", function( ) {
  if (clicks >= 1000) {
    CPS = CPS + 2;
    clicks = clicks - 1000;
  }
});
onEvent("back", "click", function( ) {
  setScreen("Clicker");
});
onEvent("Shop", "click", function( ) {
  setScreen("shop");
});
onEvent("Autoclicker", "click", function( ) {
  if (clicks >= 2000) {
    CPS = CPS + 4;
    clicks = clicks - 5000;
  }
});
onEvent("button+8", "click", function( ) {
  if (clicks >= 50000) {
    clicks = clicks - 50000;
    pointsperclick = pointsperclick + 5;
    setText("labelCounter", clicks);
    setProperty("button+8", "hidden", true);
    setProperty("label8", "hidden", true);
  }
});
onEvent("button9", "click", function( ) {
  setScreen("updatelog");
});
onEvent("Back", "click", function( ) {
  setScreen("Home");
});
onEvent("+10Clikcs", "click", function( ) {
  if (clicks >= 100000) {
    clicks = clicks - 100000;
    pointsperclick = pointsperclick + 10;
    setText("labelCounter", clicks);
    setProperty("label2", "hidden", true);
    setProperty("+10Clikcs", "hidden", true);
  }
});
onEvent("disighn", "click", function( ) {
  setScreen("design");
});
onEvent("Red", "click", function( ) {
  setProperty("Clicker", "background-color", "red");
  setProperty("shop", "background-color", "red");
  setProperty("design", "background-color", "red");
  setScreen("Clicker");
});
onEvent("Back1", "click", function( ) {
  setScreen("Clicker");
});
onEvent("White", "click", function( ) {
  setProperty("Clicker", "background-color", "white");
  setProperty("design", "background-color", "white");
  setScreen("Clicker");
  setProperty("shop", "background-color", "white");
  setProperty("labelCounter", "text-color", "#000000");
  setProperty("label5", "text-color", "#000000");
});
onEvent("Autoclicker2", "click", function( ) {
  if (clicks >= 10000) {
    CPS = CPS + 10;
    clicks = clicks - 10000;
    setText("labelCounter", "clicks");
  }
});
onEvent("button2", "click", function( ) {
  setProperty("design", "background-color", "blue");
  setProperty("shop", "background-color", "blue");
  setScreen("Clicker");
  setProperty("Clicker", "background-color", "blue");
});
onEvent("button3", "click", function( ) {
  setProperty("Clicker", "background-color", "#000000");
  setProperty("label5", "text-color", "white");
  setProperty("labelCounter", "text-color", "white");
  setProperty("design", "background-color", "#000000");
  setProperty("shop", "background-color", "#000000");
  setScreen("Clicker");
});
onEvent("Ascend", "click", function( ) {
  if (clicks >= 1000000) {
    setScreen("ascend");
  }
});
onEvent("yes", "click", function( ) {
  setScreen("Clicker");
  setProperty("label12", "hidden", true);
  setProperty("Ascend", "hidden", true);
  clicks = 0;
  CPS = 0;
  pointsperclick = pointsperclick + 50;
  if (getText("t") == "940") {
    CPS = CPS + 1000;
    pointsperclick = pointsperclick + 99;
  }
  setText("1", "You ");
  setProperty("1", "hidden", false);
  setProperty("shut-it", "hidden", false);
  setProperty("button6", "background-color", "green");
  Ach["ascend."]=true;
});
onEvent("no", "click", function( ) {
  setScreen("Clicker");
});
onEvent("Suggestions", "click", function( ) {
  setScreen("Suggestionsscreen");
});
onEvent("enter", "click", function( ) {
  setScreen("Home");
  createRecord("Ideas", {Ideas:(getText("text_input1"))}, function() {
    
  });
});
onEvent("Back2", "click", function( ) {
  setScreen("Home");
});
onEvent("suggestions", "click", function( ) {
  setScreen("Suggestionsscreen");
});
onEvent("JOE", "click", function( ) {
  setProperty("JOE", "hidden", true);
  clicks = clicks + 90000;
  setText("1", "you clicked JOE");
  setProperty("1", "hidden", false);
  setProperty("shut-it", "hidden", false);
  setProperty("Joe", "background-color", "green");
  Ach["Joe."]=true;
});
onEvent("JOE", "mousemove", function( ) {
  setPosition("JOE", randomNumber(1, 225), randomNumber(1, 225), 100, 50);
});
onEvent("JOE", "mouseover", function( ) {
   setPosition("JOE", randomNumber(1, 225), randomNumber(1, 225), 100, 50);
});
onEvent("button1", "click", function( ) {
  setProperty("design", "background-color", "#fd9408");
  setProperty("shop", "background-color", "#fd9408");
  setScreen("Clicker");
  setProperty("Clicker", "background-color", "#fd9408");
});
onEvent("Timemechine", "click", function( ) {
  setScreen("Time");
});
onEvent("Upd1", "click", function( ) {
  setScreen("Upd1screen");
});
onEvent("button11", "mousedown", function( ) {
  clicks = clicks + pointsperclick;
  setText("labelcounter", clicks);
});
onEvent("Back3", "click", function( ) {
  setScreen("Home");
});
onEvent("button12", "click", function( ) {
  setScreen("Home");
});
onEvent("button4", "click", function( ) {
  setScreen("More");
});
onEvent("Back5", "click", function( ) {
  setScreen("Home");
});
onEvent("yes1", "click", function( ) {
  setScreen("Home");
  createRecord("Report", {Problem:(getText("Reporttext"))}, function() {
    
  });
});
onEvent("Report", "click", function( ) {
  setScreen("Reportscreen");
});
onEvent("Back4", "click", function( ) {
  setScreen("Home");
});
onEvent("Home1", "click", function( ) {
  setScreen("Home");
});
onEvent("Dev", "click", function( ) {
  setScreen("dev");
});
onEvent("Bake", "click", function( ) {
  setScreen("Home");
});
onEvent("Submit", "click", function( ) {
  if (getText("t") == "940") {
    CPS = CPS + 1000;
    pointsperclick = pointsperclick + 99;
  }
  setScreen("Home");
});
onEvent("WeaklyCode", "click", function( ) {
  setScreen("WeaklyCodescreen");
});
onEvent("Yes", "click", function( ) {
  if (getText("Code") == "Critical Clicker") {
     CPS = CPS + 1;
     setProperty("WeaklyCode", "hidden", true);
   }
  setScreen("Home");
});
onEvent("Cool", "click", function( ) {
  setScreen("Home");
});
onEvent("boo", "click", function( ) {
  setScreen("Achevement");
});
onEvent("button10", "click", function( ) {
  setScreen("Home");
});
function advancment() {
 if (clicks >= 1 &&  Ach["oneclick."]!= true) {
   setText("1", "1st Click");
   setProperty("1", "hidden", false);
   setProperty("shut-it", "hidden", false);
   setProperty("1clicks", "background-color", "green");
   Ach["oneclick."]=true;
 } else if ((clicks >= 100 &&  Ach["100"]!= true)) {
   setText("1", "100th Click");
   setProperty("1", "hidden", false);
   setProperty("shut-it", "hidden", false);
   setProperty("100", "background-color", "green");
   Ach["100"]=true;
 } else if ((CPS >= 1 &&  Ach["Cps."]!= true)) {
    setText("1", "First autoclicker");
    setProperty("1", "hidden", false);
    setProperty("shut-it", "hidden", false);
    setProperty("CPS", "background-color", "green");
    Ach["Cps."]=true;
 }
 }
setProperty("shut-it", "hidden", true);
onEvent("shut-it", "click", function( ) {
  setProperty("1", "hidden", true);
  setProperty("shut-it", "hidden", true);
});
onEvent("Skip", "click", function( ) {
  setScreen("Clicker");
  setText("1", "You got a Add");
  setProperty("1", "hidden", false);
  setProperty("shut-it", "hidden", false);
  setProperty("add", "background-color", "green");
  Ach["Add."]=true;
});
//Save
readRecords("Saves", {user_id: user}, function(records) {
 if (records.length > 0) {
    id = records[records.length - 1].id;
    clicks = records[records.length - 1].Clicks;
  }
 
});
function Saves() {
  if (id != undefined) {
    updateRecord("Saves", {id:id, user_id:user, Clicks:clicks}, function() {
      
    });
  } else {
    createRecord("Saves", {user_id:user, Clicks:clicks}, function(record) {
     id = record.id;
    });
   
  }
}





